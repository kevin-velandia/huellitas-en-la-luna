-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-11-2025 a las 23:15:22
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `petlove_foundation`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `adopciones`
--

CREATE TABLE `adopciones` (
  `id` int(11) NOT NULL,
  `id_animal` int(11) NOT NULL,
  `id_adoptante` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha_adopcion` date NOT NULL,
  `estado` enum('pendiente','aprobada','rechazada','completada') DEFAULT 'pendiente',
  `observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `adoptantes`
--

CREATE TABLE `adoptantes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` text NOT NULL,
  `ocupacion` varchar(100) DEFAULT NULL,
  `experiencia_mascotas` text DEFAULT NULL,
  `motivo_adopcion` text DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `animales`
--

CREATE TABLE `animales` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `especie` enum('perro','gato','otro') NOT NULL,
  `raza` varchar(50) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `tamano` enum('pequeño','mediano','grande') DEFAULT NULL,
  `genero` enum('macho','hembra') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `estado` enum('disponible','adoptado','en_proceso') DEFAULT 'disponible',
  `adoptado_por` int(11) DEFAULT NULL,
  `fecha_ingreso` date NOT NULL,
  `voluntario_id` int(11) NOT NULL,
  `vacunado` enum('si','no') DEFAULT 'no',
  `esterilizado` enum('si','no') DEFAULT 'no',
  `comportamiento` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `animales`
--

INSERT INTO `animales` (`id`, `nombre`, `especie`, `raza`, `edad`, `tamano`, `genero`, `descripcion`, `foto`, `estado`, `adoptado_por`, `fecha_ingreso`, `voluntario_id`, `vacunado`, `esterilizado`, `comportamiento`) VALUES
(3, 'Camo', 'gato', 'fino', 1, '', 'macho', 'lindo', '682b8213471d2_persa.jpg', 'en_proceso', 13, '2025-05-16', 14, 'no', 'no', 'lindo'),
(7, 'Limon', 'gato', 'Gatin', 6, 'grande', 'hembra', 'Gato cariñoso,amoroso y juicioso', 'animal_6829046812f02.jpg', 'en_proceso', 26, '2025-05-17', 13, 'si', 'no', 'cariñoso'),
(8, 'Sika', 'perro', 'mestizo', 3, 'mediano', 'hembra', 'Linda', 'animal_68290bfd49e54.jpg', 'disponible', NULL, '2025-05-17', 13, 'no', 'no', 'lindo'),
(9, 'lian', 'perro', 'golden', 4, 'grande', 'macho', 'gordo', 'animal_68293ae472192.jpg', 'en_proceso', 13, '2025-05-17', 13, 'no', 'no', 'cariñoso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos_adopcion`
--

CREATE TABLE `documentos_adopcion` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(11) NOT NULL,
  `tipo` enum('identificacion','comprobante_domicilio','fotos_hogar','contrato') NOT NULL,
  `ruta_archivo` varchar(255) NOT NULL,
  `fecha_subida` datetime NOT NULL DEFAULT current_timestamp(),
  `validado` enum('si','no','pendiente') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `donaciones_especie`
--

CREATE TABLE `donaciones_especie` (
  `id` int(11) NOT NULL,
  `id_donante` int(11) NOT NULL,
  `tipo` enum('comida','medicamentos','accesorios','otros') NOT NULL,
  `descripcion` text NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(20) DEFAULT NULL,
  `comprobante` varchar(255) DEFAULT NULL,
  `fecha_donacion` datetime DEFAULT current_timestamp(),
  `estado` enum('pendiente','recibida','rechazada') DEFAULT 'pendiente',
  `observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `donaciones_especie`
--

INSERT INTO `donaciones_especie` (`id`, `id_donante`, `tipo`, `descripcion`, `cantidad`, `unidad`, `comprobante`, `fecha_donacion`, `estado`, `observaciones`) VALUES
(1, 13, 'comida', 'comida', 1, 'kg', NULL, '2025-05-15 18:40:14', 'recibida', ''),
(2, 13, 'comida', 'comida', 1, 'kg', NULL, '2025-05-15 18:42:28', 'recibida', ''),
(3, 13, 'accesorios', 'juguete', 10, 'unidades', NULL, '2025-05-15 18:44:44', 'rechazada', ''),
(4, 13, 'medicamentos', 'Desparacitante-microbit', 100, 'pastillas', NULL, '2025-05-16 09:33:31', 'recibida', ''),
(5, 13, 'comida', 'Fino trato', 10, 'unidades', NULL, '2025-05-16 22:35:03', 'recibida', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `donaciones_monetarias`
--

CREATE TABLE `donaciones_monetarias` (
  `id` int(11) NOT NULL,
  `id_donante` int(11) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `metodo_pago` enum('efectivo','transferencia','tarjeta','otro') NOT NULL,
  `estado` enum('pendiente','aprobada','rechazada') DEFAULT 'pendiente',
  `fecha_donacion` datetime DEFAULT current_timestamp(),
  `comprobante` varchar(255) DEFAULT NULL,
  `observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `donaciones_monetarias`
--

INSERT INTO `donaciones_monetarias` (`id`, `id_donante`, `monto`, `metodo_pago`, `estado`, `fecha_donacion`, `comprobante`, `observaciones`) VALUES
(1, 11, 100000.00, 'transferencia', 'pendiente', '2025-05-15 18:46:18', NULL, NULL),
(2, 13, 50000.00, 'efectivo', 'aprobada', '2025-05-15 19:51:34', NULL, ''),
(3, 13, 50000.00, 'tarjeta', 'aprobada', '2025-05-15 19:53:05', NULL, ''),
(4, 14, 10000.00, 'efectivo', 'rechazada', '2025-05-16 00:18:34', NULL, ''),
(5, 15, 8500.00, 'efectivo', 'pendiente', '2025-05-16 09:37:40', NULL, NULL),
(6, 13, 5000.00, 'efectivo', 'rechazada', '2025-05-16 10:47:31', NULL, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estadisticas`
--

CREATE TABLE `estadisticas` (
  `id` int(11) NOT NULL,
  `total_animales` int(11) DEFAULT 0,
  `disponibles` int(11) DEFAULT 0,
  `en_proceso` int(11) DEFAULT 0,
  `adoptados` int(11) DEFAULT 0,
  `ultima_actualizacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_actualizaciones`
--

CREATE TABLE `historial_actualizaciones` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial_actualizaciones`
--

INSERT INTO `historial_actualizaciones` (`id`, `tipo`, `descripcion`, `fecha`) VALUES
(1, 'nuevo_animal', 'Se registró el animal: Limon', '2025-05-17 16:49:28'),
(2, 'nuevo_animal', 'Se registró el animal: Sika', '2025-05-17 17:21:49'),
(3, 'nuevo_animal', 'Se registró el animal: lian', '2025-05-17 20:41:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_donaciones`
--

CREATE TABLE `historial_donaciones` (
  `id` int(11) NOT NULL,
  `id_donacion` int(11) NOT NULL,
  `tipo` enum('monetaria','especie') NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `accion` varchar(50) NOT NULL,
  `detalles` text DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial_donaciones`
--

INSERT INTO `historial_donaciones` (`id`, `id_donacion`, `tipo`, `id_usuario`, `accion`, `detalles`, `fecha`) VALUES
(1, 1, 'especie', 13, 'nueva_donacion', NULL, '2025-05-15 18:40:14'),
(2, 2, 'especie', 13, 'nueva_donacion', NULL, '2025-05-15 18:42:28'),
(3, 3, 'especie', 13, 'registro', NULL, '2025-05-15 18:44:44'),
(4, 1, 'monetaria', 11, 'registro', NULL, '2025-05-15 18:46:18'),
(5, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-15 19:30:05'),
(6, 2, 'monetaria', 13, 'registro', NULL, '2025-05-15 19:51:34'),
(7, 3, 'monetaria', 13, 'registro', NULL, '2025-05-15 19:53:05'),
(8, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a procesada', '2025-05-15 21:58:25'),
(9, 2, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-15 22:20:52'),
(10, 3, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-15 22:43:46'),
(11, 3, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a pendiente', '2025-05-15 22:43:56'),
(12, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-15 22:44:09'),
(13, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-15 22:47:12'),
(14, 3, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-15 22:49:39'),
(15, 1, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-15 22:50:00'),
(16, 3, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a aprobada', '2025-05-15 22:50:44'),
(17, 2, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a aprobada', '2025-05-15 22:51:25'),
(18, 1, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a procesada', '2025-05-15 22:51:44'),
(19, 1, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-15 22:52:35'),
(20, 1, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-15 22:53:18'),
(21, 2, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-15 22:56:14'),
(22, 1, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a procesada', '2025-05-15 23:00:40'),
(23, 1, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-15 23:07:36'),
(24, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-15 23:17:08'),
(25, 4, 'monetaria', 14, 'registro', NULL, '2025-05-16 00:18:34'),
(26, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-16 08:01:50'),
(27, 2, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-16 08:07:54'),
(28, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a procesada', '2025-05-16 08:17:50'),
(29, 4, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a aprobada', '2025-05-16 08:18:23'),
(30, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-16 08:18:38'),
(31, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-16 08:18:49'),
(32, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a procesada', '2025-05-16 08:18:54'),
(33, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a pendiente', '2025-05-16 08:18:59'),
(34, 4, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-16 09:31:58'),
(35, 6, 'especie', 13, 'registro', NULL, '2025-05-16 09:33:31'),
(36, 4, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a procesada', '2025-05-16 09:35:23'),
(37, 4, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-16 09:35:30'),
(38, 5, 'monetaria', 15, 'registro', NULL, '2025-05-16 09:37:40'),
(39, 6, 'monetaria', 13, 'registro', NULL, '2025-05-16 10:47:31'),
(40, 6, 'monetaria', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-16 10:51:03'),
(41, 3, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a rechazada', '2025-05-16 10:51:29'),
(42, 7, 'especie', 13, 'registro', NULL, '2025-05-16 22:35:03'),
(43, 5, 'especie', 11, 'edicion', 'Actualización: Estado cambiado a recibida', '2025-05-16 22:39:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` enum('comida','medicamento','limpieza','accesorio','otro') NOT NULL,
  `cantidad` int(11) NOT NULL,
  `unidad` varchar(20) NOT NULL,
  `proveedor` varchar(100) DEFAULT NULL,
  `fecha_ingreso` date NOT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `estado` enum('disponible','bajo','agotado','vencido') DEFAULT 'disponible'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id`, `nombre`, `tipo`, `cantidad`, `unidad`, `proveedor`, `fecha_ingreso`, `fecha_vencimiento`, `ubicacion`, `estado`) VALUES
(1, 'Donación #1: Comida', 'comida', 1, 'kg', NULL, '2025-05-15', NULL, NULL, 'disponible'),
(2, 'Donación #2: Comida', 'comida', 1, 'kg', '', '2025-05-15', NULL, NULL, 'agotado'),
(4, 'juguetes', 'accesorio', 1, 'unidades', '', '2025-05-16', NULL, NULL, 'disponible'),
(6, 'Donación #4: Medicamentos', 'medicamento', 100, 'pastillas', NULL, '2025-05-16', NULL, NULL, 'disponible'),
(7, 'Donación #5: Comida', 'comida', 10, 'unidades', NULL, '2025-05-16', NULL, NULL, 'disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `mensaje` text NOT NULL,
  `leida` tinyint(1) DEFAULT 0,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `usuario_id`, `tipo`, `mensaje`, `leida`, `fecha`) VALUES
(1, 17, 'adopcion_rechazada', 'Lamentamos informarte que tu solicitud para adoptar a \\\'Sika\\\' ha sido rechazada.', 0, '2025-05-19 15:39:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seguimiento_adopciones`
--

CREATE TABLE `seguimiento_adopciones` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(11) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `admin_id` int(11) DEFAULT NULL,
  `tipo` enum('visita','seguimiento','problema','finalizacion') NOT NULL,
  `descripcion` text NOT NULL,
  `responsable_id` int(11) NOT NULL COMMENT 'ID del voluntario/admin',
  `documento` varchar(255) DEFAULT NULL COMMENT 'Ruta a documento/pdf'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `seguimiento_adopciones`
--

INSERT INTO `seguimiento_adopciones` (`id`, `solicitud_id`, `fecha`, `admin_id`, `tipo`, `descripcion`, `responsable_id`, `documento`) VALUES
(1, 9, '2025-05-19 15:00:55', NULL, 'seguimiento', 'Solicitud aprobada - Inicio proceso de adopción', 11, NULL),
(2, 8, '2025-05-19 15:02:27', NULL, 'seguimiento', 'Solicitud aprobada - Inicio proceso de adopción', 11, NULL),
(9, 9, '2025-05-19 16:46:49', NULL, '', '', 11, NULL),
(10, 11, '2025-11-05 11:42:20', NULL, 'seguimiento', 'Solicitud aprobada - Inicio proceso de adopción', 24, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes_adopcion`
--

CREATE TABLE `solicitudes_adopcion` (
  `id` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `motivo` text NOT NULL,
  `experiencia` text NOT NULL,
  `hogar` text NOT NULL,
  `fecha_solicitud` datetime NOT NULL,
  `estado` enum('pendiente','aprobada','rechazada','completada','cancelada') DEFAULT 'pendiente',
  `admin_id` int(11) DEFAULT NULL COMMENT 'ID del administrador que revisó la solicitud',
  `fecha_revision` datetime DEFAULT NULL COMMENT 'Fecha de revisión por el admin',
  `comentarios_admin` text DEFAULT NULL COMMENT 'Comentarios del administrador',
  `fecha_actualizacion` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `metodo_contacto` enum('email','telefono','whatsapp','presencial') NOT NULL DEFAULT 'email',
  `estado_previo` enum('pendiente','aprobada','rechazada') DEFAULT NULL COMMENT 'Para historial de cambios',
  `fecha_resolucion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `solicitudes_adopcion`
--

INSERT INTO `solicitudes_adopcion` (`id`, `animal_id`, `usuario_id`, `motivo`, `experiencia`, `hogar`, `fecha_solicitud`, `estado`, `admin_id`, `fecha_revision`, `comentarios_admin`, `fecha_actualizacion`, `metodo_contacto`, `estado_previo`, `fecha_resolucion`) VALUES
(8, 3, 13, 'me gustan', 'si', 'si', '2025-05-17 17:06:15', 'aprobada', 11, NULL, NULL, '2025-05-19 15:02:27', 'whatsapp', NULL, '2025-05-19 15:02:27'),
(9, 9, 13, 'si', 'si', 'si', '2025-05-17 20:42:26', 'aprobada', 11, NULL, NULL, '2025-05-19 15:00:55', 'whatsapp', NULL, '2025-05-19 15:00:55'),
(10, 8, 17, 'hjdfk', 'fgshdj', 'ghsjdkf', '2025-05-19 15:23:48', '', 11, NULL, NULL, '2025-05-19 15:39:45', 'whatsapp', NULL, '2025-05-19 15:39:45'),
(11, 7, 26, 'juan', 'jan', 'jajaja', '2025-11-05 11:40:48', 'aprobada', 24, NULL, NULL, '2025-11-05 11:42:20', 'whatsapp', NULL, '2025-11-05 11:42:20');

--
-- Disparadores `solicitudes_adopcion`
--
DELIMITER $$
CREATE TRIGGER `after_solicitud_aprobada` AFTER UPDATE ON `solicitudes_adopcion` FOR EACH ROW BEGIN
    IF NEW.estado = 'aprobada' AND OLD.estado != 'aprobada' THEN
        UPDATE `animales` 
        SET `estado` = 'en_proceso', 
            `adoptado_por` = NEW.usuario_id
        WHERE `id` = NEW.animal_id;
        
        INSERT INTO `seguimiento_adopciones` 
        (`solicitud_id`, `tipo`, `descripcion`, `responsable_id`)
        VALUES (NEW.id, 'seguimiento', 'Solicitud aprobada - Inicio proceso de adopción', NEW.admin_id);
    END IF;
    
    IF NEW.estado = 'completada' THEN
        UPDATE `animales` 
        SET `estado` = 'adoptado', 
            `fecha_adopcion` = CURDATE()
        WHERE `id` = NEW.animal_id;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `rol` enum('admin','voluntario') DEFAULT 'voluntario',
  `fecha_registro` datetime DEFAULT current_timestamp(),
  `foto_perfil` varchar(255) DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `telefono`, `direccion`, `rol`, `fecha_registro`, `foto_perfil`) VALUES
(11, 'Admin Nuevo', 'adminnuevo@fundacion.com', '$2y$10$QA./HTZoG6SlB049vHKj7.nIpoXsVUFT93pz7.9OQEUKKP2bKWAum', '3194697249', 'Sede central de la fundación', 'admin', '2025-05-15 11:36:19', 'default.jpg'),
(13, 'ROJAS SANCHEZ', 'laura@gmail.com', '$2y$10$S2oQJ0M3h8eTlMrwU.DzqOPt7A8sw9Lh2e6rQgc/Lu7icwmlgsBeO', '3194697249', 'usco', 'voluntario', '2025-05-15 17:27:34', 'default.jpg'),
(14, 'andres leandro', 'andres@gmail.com', '$2y$10$NmSp5LyERhkVqda8wrWbn.DdIv4kDZztwOY5MYAqdUtPRYNoPozAO', '3158301742', NULL, 'voluntario', '2025-05-16 00:17:38', 'default.jpg'),
(15, 'Juan Pablo', 'juanpis@gmail.com', '$2y$10$guUdreoAisBpIwHDtA1FIukaEI.9U5V9o9gN3.N9D4zIGxSK/SMPa', '3198153245', NULL, 'voluntario', '2025-05-16 09:36:44', 'default.jpg'),
(17, 'Sara', 'sara@gmail.com', '$2y$10$Tal4S.MznwfA/5jqvHl7n.r/j2WE8qHchHneCIhZtueNzuE3/FoTy', '3124567456', 'Cali', 'voluntario', '2025-05-17 16:53:03', 'default.jpg'),
(22, 'kevin1', 'kevin1@gmail.com', '123123123', NULL, 'juncal', 'voluntario', '2025-09-22 00:58:02', 'default.jpg'),
(24, 'valen', 'valen@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, 'mi corazon', 'admin', '2025-09-22 01:07:22', 'default.jpg'),
(25, 'kevin admin', 'velandiakevin843@gmail.com', '$2y$10$ZV28fxyRcPsy9YH0wCXSleMAJVVBvkPaa7dYzLkIx4lPFunRfE5oC', '3213476400', NULL, 'admin', '2025-11-03 21:35:11', 'default.jpg'),
(26, 'kevin', 'kevin12@gmail.com', '$2y$10$5GEZiOPxM6uFyX9xBEi/6.B6aSlID6qfXu0wfZKy1nTD6Xo3nVQ7G', '3213476400', 'juncal', 'voluntario', '2025-11-05 11:20:58', 'default.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `adopciones`
--
ALTER TABLE `adopciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_animal` (`id_animal`),
  ADD KEY `id_adoptante` (`id_adoptante`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `adoptantes`
--
ALTER TABLE `adoptantes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `animales`
--
ALTER TABLE `animales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `voluntario_id` (`voluntario_id`);

--
-- Indices de la tabla `documentos_adopcion`
--
ALTER TABLE `documentos_adopcion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitud_id` (`solicitud_id`);

--
-- Indices de la tabla `donaciones_especie`
--
ALTER TABLE `donaciones_especie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_donaciones_fecha` (`fecha_donacion`),
  ADD KEY `fk_especie_usuario` (`id_donante`);

--
-- Indices de la tabla `donaciones_monetarias`
--
ALTER TABLE `donaciones_monetarias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_donaciones_fecha` (`fecha_donacion`),
  ADD KEY `fk_monetaria_usuario` (`id_donante`);

--
-- Indices de la tabla `estadisticas`
--
ALTER TABLE `estadisticas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `historial_actualizaciones`
--
ALTER TABLE `historial_actualizaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `historial_donaciones`
--
ALTER TABLE `historial_donaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_inventario_estado` (`estado`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `seguimiento_adopciones`
--
ALTER TABLE `seguimiento_adopciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitud_id` (`solicitud_id`),
  ADD KEY `responsable_id` (`responsable_id`);

--
-- Indices de la tabla `solicitudes_adopcion`
--
ALTER TABLE `solicitudes_adopcion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_estado` (`estado`),
  ADD KEY `idx_fecha` (`fecha_solicitud`),
  ADD KEY `idx_animal` (`animal_id`,`estado`),
  ADD KEY `idx_usuario` (`usuario_id`,`fecha_solicitud`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `adopciones`
--
ALTER TABLE `adopciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `adoptantes`
--
ALTER TABLE `adoptantes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `animales`
--
ALTER TABLE `animales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `documentos_adopcion`
--
ALTER TABLE `documentos_adopcion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `donaciones_especie`
--
ALTER TABLE `donaciones_especie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `donaciones_monetarias`
--
ALTER TABLE `donaciones_monetarias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `estadisticas`
--
ALTER TABLE `estadisticas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `historial_actualizaciones`
--
ALTER TABLE `historial_actualizaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `historial_donaciones`
--
ALTER TABLE `historial_donaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `seguimiento_adopciones`
--
ALTER TABLE `seguimiento_adopciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `solicitudes_adopcion`
--
ALTER TABLE `solicitudes_adopcion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `adopciones`
--
ALTER TABLE `adopciones`
  ADD CONSTRAINT `adopciones_ibfk_1` FOREIGN KEY (`id_animal`) REFERENCES `animales` (`id`),
  ADD CONSTRAINT `adopciones_ibfk_2` FOREIGN KEY (`id_adoptante`) REFERENCES `adoptantes` (`id`),
  ADD CONSTRAINT `adopciones_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `animales`
--
ALTER TABLE `animales`
  ADD CONSTRAINT `animales_ibfk_1` FOREIGN KEY (`voluntario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `documentos_adopcion`
--
ALTER TABLE `documentos_adopcion`
  ADD CONSTRAINT `documentos_adopcion_ibfk_1` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_adopcion` (`id`);

--
-- Filtros para la tabla `donaciones_especie`
--
ALTER TABLE `donaciones_especie`
  ADD CONSTRAINT `fk_especie_usuario` FOREIGN KEY (`id_donante`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `donaciones_monetarias`
--
ALTER TABLE `donaciones_monetarias`
  ADD CONSTRAINT `fk_monetaria_usuario` FOREIGN KEY (`id_donante`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `historial_donaciones`
--
ALTER TABLE `historial_donaciones`
  ADD CONSTRAINT `fk_historial_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `seguimiento_adopciones`
--
ALTER TABLE `seguimiento_adopciones`
  ADD CONSTRAINT `seguimiento_adopciones_ibfk_1` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_adopcion` (`id`),
  ADD CONSTRAINT `seguimiento_adopciones_ibfk_2` FOREIGN KEY (`responsable_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `solicitudes_adopcion`
--
ALTER TABLE `solicitudes_adopcion`
  ADD CONSTRAINT `solicitudes_adopcion_ibfk_1` FOREIGN KEY (`animal_id`) REFERENCES `animales` (`id`),
  ADD CONSTRAINT `solicitudes_adopcion_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
